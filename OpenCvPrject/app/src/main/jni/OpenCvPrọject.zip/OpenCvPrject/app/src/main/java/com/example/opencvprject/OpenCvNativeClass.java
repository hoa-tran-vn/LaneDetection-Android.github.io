package com.example.opencvprject;

public class OpenCvNativeClass {
    public native static  int convertGray(long matAddrRgba, long matAddrGray);
}
